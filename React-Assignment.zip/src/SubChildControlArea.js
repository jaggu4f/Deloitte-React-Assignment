import React from 'react';
import { Accordion,AccordionSummary,AccordionDetails,Typography } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Delete } from '@material-ui/icons';

 const SubChildControlArea = (props) => {
    const { rows,rootId,parentId } = props;
    const removeControlArea = (event,level) => (props.removeControlArea(event,level))
    return(
        <Typography>
            {rows && rows.length > 0 && rows.map((row,index) => {
              return(
                <>
                  <Accordion>
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls={`panel1a-content-${index}`}
                      id={`sub-child-control-area-${index+1}`}
                    >
                      <Typography >
                          <span>{row.id}</span>
                          <span>
                              Remove<Delete color="secondary" parentId={parentId} rootId={rootId} name={row.id} onClick={(event) => removeControlArea(event,'subchild')} />
                          </span>
                      </Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                      <Typography>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex,
                        sit amet blandit leo lobortis eget.
                      </Typography>
                    </AccordionDetails>
                  </Accordion>
              </>
              )
        })}
      </Typography>
    )
}

export default React.memo(SubChildControlArea);