import React from 'react';
import { Accordion,AccordionSummary,AccordionDetails,Typography } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Add,Delete } from '@material-ui/icons';
import  ChildControlArea  from './ChildControlArea'

class AccordianControlArea extends React.Component {
  constructor(props) {
    super(props);
    this.state={
      isInputChanged : false,
    }
  }
updateAreaLabel = (event,id) => {
    if(event.target.name === id){
      this.setState((state)=>event.target.value !== state[event.target.name] ? {[event.target.name]: event.target.value,isInputChanged:true} :null);
    }
  };
addControlArea = (event,level) => (this.props.addControlArea(event,level))

removeControlArea = (event,level) => (this.props.removeControlArea(event,level))
render(){
  const { rows } = this.props;
  return(
    <section>
      {rows.length > 0 && rows.map((row,index) => {
        return(
          <div key={row.id}>
            <Accordion >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls={`panel1a-content-${index}`}
                name={row.id}
                name={row.id}
                style={{'background':'lightblue','width':'100%',}}
              >
                <Typography style={{'background':'lightblue','width':'100%'}}>
                  <input style={{'background':'lightblue','width':'60%','border':'none'}} value={this.state.isInputChanged ? this.state[`maincontrl-input-${index+1}`] : row.id} name={`maincontrl-input-${index+1}`} id={`maincontrl-input-${index+1}`} onChange={(event)=>this.updateAreaLabel(event,`maincontrl-input-${index+1}`)}/>
                  <span style={{'float':'right'}}> 
                      Add <Add color="primary" name={row.id} onClick={(event) => this.addControlArea(event,'main')} />
                      Remove<Delete color="secondary" name={row.id} onClick={(event) => this.removeControlArea(event,'main')} />
                  </span>
                </Typography>
              </AccordionSummary>
              <AccordionDetails style={{'background':'lightblue'}}>
                <ChildControlArea rows={row.child} rootId={row.id} removeControlArea={(event,label) => this.removeControlArea(event,label)} addControlArea={(event,label)=>this.addControlArea(event,label)}/>
              </AccordionDetails>
            </Accordion>
        </div>
        )
      })}
      </section>
  )
}
}

export default React.memo(AccordianControlArea)