import React from 'react';
import { Accordion,AccordionSummary,AccordionDetails,Typography } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Add,Delete } from '@material-ui/icons';
import SubChildControlArea from './SubChildControlArea'

class ChildControlArea extends React.Component {
  constructor(props) {
        super(props);
        this.state={
          isInputChanged : false,
        }
      }
  addChildControlArea = (event,level) => (this.props.addControlArea(event,level))

  removeControlArea = (event,level) => (this.props.removeControlArea(event,level))

  updateAreaLabel = (event,id) => {
          if(event.target.name === id){
            this.setState({[event.target.name]: event.target.value,isInputChanged:true,});
          }
        };
  render(){
    const { rows,rootId } = this.props;
    return(
        <Typography style={{'background':'lightgray','width':'95%','dispaly':'block'}}>
            {rows && rows.length > 0 && rows.map((row,index) => {
              return(
                <>
                  <Accordion >
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls={`panel1a-content-${index}`}
                      id={`child-control-area-${index+1}`}
                      style={{'background':'lightgray','width':'100%','dispaly':'block'}}
                    >
                          <Typography style={{'background':'lightgray','width':'100%','dispaly':'block'}}>
                              <input style={{'background':'lightgray','width':'60%','border':'none'}} value={this.state.isInputChanged ? this.state[`childcontrl-input-${index+1}`] : row.id} name={`childcontrl-input-${index+1}`} id={`childcontrl-input-${index+1}`} onChange={(event)=>this.updateAreaLabel(event,`childcontrl-input-${index+1}`)}/>
                              <span style={{'float':'right'}}>
                                  Add <Add color="primary" parentId={rootId} name={row.id} onClick={(event) => this.addChildControlArea(event,'child')} />
                                  Remove<Delete color="secondary" parentId={rootId} name={row.id} onClick={(event) => this.removeControlArea(event,'child')} />
                              </span>
                          </Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                          <SubChildControlArea rootId={rootId} parentId={row.id} rows={row.children} removeControlArea={(event,label) => this.removeControlArea(event,label)}/>
                    </AccordionDetails>
                  </Accordion>
              </>
              )
            })}
          </Typography>
    )
  }
}

export default React.memo(ChildControlArea)