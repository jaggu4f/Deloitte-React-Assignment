import React  from 'react';
import AccordianControlArea  from './AccordianControlArea'
import { Button } from '@material-ui/core';
import { Add } from '@material-ui/icons';


class App extends React.Component {
  constructor(props) {
    super(props);
    this.state={
      data:[],
    }
    this.count=0;
  }
  addControlArea = (event,level) => {
    if(level==='child'){
      let childControlArea = this.state.data.find(item=>item.id === event.target.closest('svg').getAttribute("parentId"));
      let subchildControlArea = childControlArea && childControlArea.child.find(item=>item.id === event.target.closest('svg').getAttribute("name"));
      subchildControlArea && subchildControlArea.children.push({id:`subChildControlAarea-${subchildControlArea.children.length+1}`,parentId:`childControlArea-${subchildControlArea.children.length+1}`,label:`Sub Child Control Area ${subchildControlArea.children.length+1}`})
      this.setState({subchildControlArea,count:this.state.data.length})
    }else{
      let childControlArea = this.state.data.find(item=>item.id === event.target.closest('svg').getAttribute("name"));
      childControlArea && childControlArea.child.push({id:`childControlArea-${childControlArea.child.length+1}`,parentId:childControlArea.id, label:`Child Control Area ${childControlArea.child.length+1}`,children:[]})
      this.setState({childControlArea,count:this.state.data.length})
    }
  }
  removeControlArea = (event,level) => {
    if(level === 'child'){
      let res = this.state.data.find((item)=>item.id === event.target.closest('svg').getAttribute("parentId"));
      let result = res.child.filter((item)=>item.id !== event.target.closest('svg').getAttribute("name"))
      res.child=[...result];
      this.setState({data:[...this.state.data,res]})
    }else if(level === 'subchild'){
      let res = this.state.data.find((item)=>item.id === event.target.closest('svg').getAttribute("rootId"));
      let result = res.child.find((item)=>item.id === event.target.closest('svg').getAttribute("parentId"));
      let resultData = result.children.filter((item)=>item.id !== event.target.closest('svg').getAttribute("name"))
      result.children=[...resultData];
      this.setState({data:[...this.state.data,res]})
    }else{
      let res = this.state.data.filter((item)=>item.id !== event.target.closest('svg').getAttribute("name"))
      this.setState({data:res})
    }
  }
  createControlArea = () => {
    this.count++;
    this.setState({data:[...this.state.data,{id:`mainControlArea-${this.count}`,label:`Control Area ${this.count}`,child:[]}],count:this.state.data.length})
  }
  render() {
    return (
    <div >
      <Button
        variant="contained"
        color="primary"
        startIcon={<Add />}
        onClick={() => this.createControlArea()}
        style={{margin:'0 40%',width:'20%'}}
      >
        Add Control Area
      </Button>
      <AccordianControlArea  rows={this.state.data} removeControlArea={(event,level)=>this.removeControlArea(event,level)} addControlArea={(event,level)=>{this.addControlArea(event,level)}}/>
    </div>
  );
}
}

export default App;
