import React,{ useState } from 'react';
import { Add } from '@material-ui/icons';
import { makeStyles } from '@material-ui/core/styles';
import { Button } from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
    root: {
      width: '80%',
      margin:'0 auto',
      'margin-top':'20px'
    },
    heading: {
      fontSize: theme.typography.pxToRem(15),
      fontWeight: theme.typography.fontWeightRegular,
    },
  }));

export const AddControlArea = (props) => {
    const classes = useStyles();
    const { styleClasses,uniqueId } = props;
    const data = []
    const [row,setRow] = useState(data);
    const createControlArea = () => {
        let obj = {id:`main-control-area-${uniqueId}`,label:`Control Area ${uniqueId}`,child:[]}
        setRow(obj);
        props.getData(row)
    }
    return(
        <Button
        variant="contained" 
        color="primary"
        className={classes.button}
        startIcon={<Add />}
        onClick={() => createControlArea()}
        data={row}
      >
        Add Control Area
      </Button>
    )
}